﻿
namespace ExpenseManager
{
    partial class UC_Transection
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Transection));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.btnIcon = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnIcon
            // 
            this.btnIcon.AllowAnimations = true;
            this.btnIcon.AllowMouseEffects = true;
            this.btnIcon.AllowToggling = false;
            this.btnIcon.AnimationSpeed = 200;
            this.btnIcon.AutoGenerateColors = false;
            this.btnIcon.AutoRoundBorders = false;
            this.btnIcon.AutoSizeLeftIcon = true;
            this.btnIcon.AutoSizeRightIcon = true;
            this.btnIcon.BackColor = System.Drawing.Color.Transparent;
            this.btnIcon.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.btnIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnIcon.BackgroundImage")));
            this.btnIcon.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnIcon.ButtonText = "";
            this.btnIcon.ButtonTextMarginLeft = 0;
            this.btnIcon.ColorContrastOnClick = 45;
            this.btnIcon.ColorContrastOnHover = 45;
            this.btnIcon.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btnIcon.CustomizableEdges = borderEdges3;
            this.btnIcon.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnIcon.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnIcon.DisabledFillColor = System.Drawing.Color.Empty;
            this.btnIcon.DisabledForecolor = System.Drawing.Color.Empty;
            this.btnIcon.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnIcon.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnIcon.ForeColor = System.Drawing.Color.White;
            this.btnIcon.IconLeft = ((System.Drawing.Image)(resources.GetObject("btnIcon.IconLeft")));
            this.btnIcon.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIcon.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnIcon.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnIcon.IconMarginLeft = 11;
            this.btnIcon.IconPadding = 10;
            this.btnIcon.IconRight = null;
            this.btnIcon.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnIcon.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnIcon.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnIcon.IconSize = 25;
            this.btnIcon.IdleBorderColor = System.Drawing.Color.Empty;
            this.btnIcon.IdleBorderRadius = 0;
            this.btnIcon.IdleBorderThickness = 0;
            this.btnIcon.IdleFillColor = System.Drawing.Color.Empty;
            this.btnIcon.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnIcon.IdleIconLeftImage")));
            this.btnIcon.IdleIconRightImage = null;
            this.btnIcon.IndicateFocus = false;
            this.btnIcon.Location = new System.Drawing.Point(19, 22);
            this.btnIcon.Name = "btnIcon";
            this.btnIcon.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnIcon.OnDisabledState.BorderRadius = 10;
            this.btnIcon.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnIcon.OnDisabledState.BorderThickness = 1;
            this.btnIcon.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnIcon.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnIcon.OnDisabledState.IconLeftImage = null;
            this.btnIcon.OnDisabledState.IconRightImage = null;
            this.btnIcon.onHoverState.BorderColor = System.Drawing.Color.White;
            this.btnIcon.onHoverState.BorderRadius = 10;
            this.btnIcon.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnIcon.onHoverState.BorderThickness = 1;
            this.btnIcon.onHoverState.FillColor = System.Drawing.Color.White;
            this.btnIcon.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnIcon.onHoverState.IconLeftImage = null;
            this.btnIcon.onHoverState.IconRightImage = null;
            this.btnIcon.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.btnIcon.OnIdleState.BorderRadius = 10;
            this.btnIcon.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnIcon.OnIdleState.BorderThickness = 1;
            this.btnIcon.OnIdleState.FillColor = System.Drawing.Color.White;
            this.btnIcon.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnIcon.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.OnIdleState.IconLeftImage")));
            this.btnIcon.OnIdleState.IconRightImage = null;
            this.btnIcon.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnIcon.OnPressedState.BorderRadius = 10;
            this.btnIcon.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnIcon.OnPressedState.BorderThickness = 1;
            this.btnIcon.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnIcon.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnIcon.OnPressedState.IconLeftImage = null;
            this.btnIcon.OnPressedState.IconRightImage = null;
            this.btnIcon.Size = new System.Drawing.Size(42, 39);
            this.btnIcon.TabIndex = 3;
            this.btnIcon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIcon.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnIcon.TextMarginLeft = 0;
            this.btnIcon.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnIcon.UseDefaultRadiusAndThickness = true;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(254)))));
            this.lblDate.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblDate.Location = new System.Drawing.Point(78, 44);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(78, 17);
            this.lblDate.TabIndex = 4;
            this.lblDate.Text = "04 Feb 2022";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(254)))));
            this.lblTitle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTitle.Location = new System.Drawing.Point(78, 22);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(70, 16);
            this.lblTitle.TabIndex = 5;
            this.lblTitle.Text = "Shopping";
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(254)))));
            this.lblAmount.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblAmount.Location = new System.Drawing.Point(342, 31);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(45, 19);
            this.lblAmount.TabIndex = 5;
            this.lblAmount.Text = "$800";
            // 
            // UC_Transection
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(254)))));
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.btnIcon);
            this.Name = "UC_Transection";
            this.Size = new System.Drawing.Size(412, 88);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnIcon;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblAmount;
    }
}
