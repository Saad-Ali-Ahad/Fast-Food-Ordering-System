﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExpenseManager
{
    public partial class UC_Transection : UserControl
    {
        public string CardTitle
        {
            get { return lblTitle.Text; }
            set { lblTitle.Text = value;}
        }

        public string CardDate
        {
            get { return lblDate.Text; }
            set { lblDate.Text = value; }
        }

        public string CardAmount
        {
            get { return lblAmount.Text; }
            set { lblAmount.Text = value; }
        }

        public Image CardIcon
        {
            get { return btnIcon.LeftIcon.Image; }
            set { btnIcon.LeftIcon.Image = value; }
        }

        public UC_Transection()
        {
            InitializeComponent();
        }
    }
}
